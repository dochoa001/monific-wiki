# HISTORIAL Y CONTEXTO — CIERRE DOCUMENTAL Y TÉCNICO MONIFIC × B&O

**Proyecto:** Implementación HubSpot Monific (Solicitantes, Inversionistas, Servicio/ATC, Cobranza, UNE)
**Documento:** Registro completo de contexto, hallazgos y ruta de cierre
**Preparado por:** Emmanuel Chulin — Black & Orange
**Fecha de corte:** 3 de agosto de 2026
**Sesión de referencia:** lunes 3 de agosto de 2026, 15:00 h
**Versión:** 1.0

---

## 0. Propósito de este documento

Este archivo consolida, en un solo lugar, todo el contexto necesario para atender la solicitud de Monific del 31 de julio / 3 de agosto de 2026 sin volver a reconstruir antecedentes.

Contiene:

1. El origen y el texto de la solicitud del cliente.
2. El inventario exacto de los archivos recibidos, con su huella de verificación.
3. La estructura documental única que Monific impone a partir de esta fecha.
4. El análisis completo del maestro operativo 03 (70 fichas evaluadas).
5. El análisis completo de la matriz de comunicación (81 comunicaciones).
6. Los defectos internos detectados en los propios documentos del cliente.
7. Los conflictos entre la matriz de comunicación y las decisiones canónicas del 31 de julio.
8. La clasificación de los 70 pendientes por naturaleza y por responsable.
9. La ruta de cierre propuesta y la respuesta a las cuatro confirmaciones solicitadas.

**Criterio de rigor aplicado:** todo dato marcado como *verificado* proviene de la lectura directa de los archivos recibidos. Todo dato marcado como *por confirmar* requiere validación en el portal de HubSpot o con Monific. No se registra como cerrado ningún punto que no tenga evidencia.

El resumen ejecutivo de este mismo análisis está en `RESUMEN_EJECUTIVO_CIERRE_MONIFIC_BNO_2026-08-03.pdf`.

---

## 1. Origen: la solicitud de Monific

### 1.1 Contexto de la comunicación

Monific envió un correo a Emmanuel Chulin y David con el asunto del seguimiento al cierre del proyecto. El planteamiento central del cliente es que, además de los bugs y diferencias ya compartidos en HubSpot, **varios acuerdos, tareas y pendientes solicitados durante el proyecto no se incorporaron a los documentos maestros, al listado de tareas ni a la especificación técnica.**

### 1.2 Consecuencias que el cliente atribuye a esa omisión

Textualmente, el cliente identifica seis efectos:

1. Los documentos indicaban una cosa y HubSpot estaba configurado de otra manera.
2. Algunos acuerdos posteriores al inicio del proyecto no aparecían en ningún máster.
3. Existían workflows encendidos aunque el documento indicara que debían permanecer apagados.
4. Se mantuvieron reglas anteriores que ya habían sido modificadas.
5. Algunos pendientes no tenían responsable, evidencia ni criterio de cierre.
6. Se revisaban los mismos temas de nuevo porque no existía una fuente única actualizada.

### 1.3 Puntos que el cliente enumera explícitamente

- El formulario definitivo de Solicitantes.
- La intervención del despacho ARI en Cobranza.
- La separación entre Proyecto, onboarding y movimientos de Inversionistas.
- Las reglas de congelado y reactivación.
- El control de contactos de marketing.
- Varias inconsistencias en los workflows de cierre.

### 1.4 La estructura documental única impuesta

A partir de esta fecha, Monific establece una sola ruta de trabajo:

| # | Documento | Ubicación |
|---|---|---|
| 1 | 00_LEER_PRIMERO | Google Docs — `1Qb1f6NphfS8WF5HFzntz3bOF1oop9nAyzP4kZY_Xb7M` |
| 2 | Carpeta de másteres vigentes revisados por Monific | Google Drive — `1u4ULcwjxOKywpPZEhDah6-_8dsSgtUCN` |
| 3 | 03_MAESTRO_OPERATIVO de procesos y workflows | Google Docs — `16bvgWw3cjlgMfeItb32ydQWIzKEaPJQE3DJPHyd6d30` |
| 4 | 05_CONTROL_ÚNICO de cierre actualizado | Google Sheets — `1RPbXyowfWpGnsVQ_OYKyZI5-iFhy1T5j` |
| 5 | 02_RESPUESTA_BNO (respuestas, versiones corregidas y evidencias) | Google Drive — `1VmOKMKBGwzXFvGbf2GHdyhwALwvPhv-W` |

Másteres vigentes referenciados en el archivo 00:

| Máster | ID de Google Sheets |
|---|---|
| Comercial corregido | `1Wr55InKsdIOTTcPcpJN5jjsuaJf1mdP8` |
| Cobranza corregido | `1XvPaOypZc3lN6sqMP5amoUKpo8BRoFwT` |
| Integración HubSpot–Admin corregida | `1NsBV6m2cIq-Dk2ZzhgkFQrewzi0Yc2cd` |

Los archivos 01, 02 y 04 del corte anterior se conservan únicamente como antecedente y trazabilidad.

### 1.5 Código de color vigente

| Color | Significado literal según el cliente |
|---|---|
| **Azul claro** | **NUEVO** — no existía en el mapa / no estaba contemplado. No significa que ya esté configurado en HubSpot. |
| **Amarillo claro** | **ACTUALIZADO** — se corrigió la definición documental, pero continúa pendiente de implementación, evidencia o prueba. |

Regla explícita del cliente: *"Ninguna fila nueva se considera implementada ni verificada sólo por haber sido incorporada al documento"* y *"Ningún punto se considera cerrado únicamente por aparecer en el documento o por existir en HubSpot."*

### 1.6 Formato de evidencia exigido por pendiente

Monific exige que la respuesta de B&O se haga sobre los mismos másteres y el Control Único, indicando para cada pendiente:

1. Qué se corrigió.
2. Qué versión se sustituye.
3. URL o ID de la configuración.
4. Evidencia antes y después.
5. Caso de prueba.
6. Resultado esperado y resultado real.
7. Fecha de ejecución.

### 1.7 Las cuatro confirmaciones solicitadas

1. Recepción y acceso a la estructura.
2. Que se trabajará sobre estas versiones y no se creará una matriz adicional.
3. Si se confirma la sesión del lunes a las 15:00 h.
4. Qué correcciones podrán quedar incorporadas antes de la reunión.

El cliente además ofrece una alternativa: si B&O considera que necesita primero terminar la revisión y corregir pendientes antes de reunirse, debe indicar qué puede dejar atendido antes del lunes y qué puntos propone resolver durante la sesión.

### 1.8 Alcance expresamente excluido

- El maestro de **Servicio y UNE no fue modificado** en este corte.
- **Retiros y UNE quedan expresamente fuera del ciclo de Inversionistas.**

---

## 2. Inventario documental recibido y verificado

| Archivo | Tamaño | Verificación |
|---|---|---|
| `00_LEER_PRIMERO_ACTUALIZACION_SOLICITANTES_E_INVERSIONISTAS_2026-07-31.md` | — | Leído íntegro (34 líneas) |
| `03_MAESTRO_OPERATIVO_PROCESOS_Y_WORKFLOWS_MONIFIC_BNO_ACTUALIZADO_INVERSIONISTAS_2026-07-31.md` | 227,520 bytes | SHA-256 `E8821CD2843F4059CFEF21F5F4BAFFC76A4E2EF1AFEF391449CE758088E6D0A5` |
| `03_..._2026-07-31 (1).md` | 227,520 bytes | **Hash idéntico al anterior** — es el mismo archivo, no una versión distinta |
| `05_CONTROL_UNICO_CIERRE_BNO_ACTUALIZADO_INVERSIONISTAS_2026-07-31.xlsx` | — | Analizado |
| `03. Matriz completa de comunicación (1).md` | 107,373 bytes | 602 líneas, analizado íntegro |

**Nota de trazabilidad:** la duplicidad del archivo 03 se verificó por hash criptográfico, no por inspección visual. Ambos archivos son byte-idénticos.

---

## 3. Análisis del maestro operativo 03

### 3.1 Universo evaluado

| Concepto | Cantidad |
|---|---|
| Fichas totales evaluadas | **70** |
| Workflows canónicos (WF-001 a WF-064) | 64 |
| Flujos UNE (UNE-01 a UNE-06) | 6 |
| Fichas en **verde** (implementado y verificado) | **0** |
| Fichas en **rojo** (con errores o bugs) | **29** |
| Fichas en **amarillo** (pendiente de implementación, evidencia o prueba) | **41** |

### 3.2 Distribución de rojos por proceso

| Proceso | Rojos | Identificadores |
|---|---|---|
| Solicitantes | 7 | WF-003, WF-004, WF-007, WF-010, WF-011, WF-020, WF-021 |
| Inversionistas | 3 | WF-034, WF-035, WF-039 |
| Servicio / ATC | **0** | — |
| Cobranza | 13 | WF-050 a WF-062 |
| UNE | 6 | UNE-01 a UNE-06 |
| **Total** | **29** | |

### 3.3 Cobertura contra el portal

| Concepto | Cantidad | Observación |
|---|---|---|
| Workflows en el portal de HubSpot | 96 | |
| Workflows canónicos en los másteres | 64 | |
| Coincidencia exacta por nombre | 59 | |
| Diferencia de nombre declarada por el documento | 5 | Solo documenta 4 (ver 3.6) |
| **Workflows del portal sin mapear a ningún máster** | **32** | No explicados en ningún documento |

---

## 4. Taxonomía completa de los errores documentados

El documento agrupa bajo la misma etiqueta "rojo" nueve tipos de problema con esfuerzo de corrección radicalmente distinto. Esta es la desagregación.

### 4.1 Familia 1 — Inscripción automática a secuencias (5 casos)

**Naturaleza:** limitación de licencia / regla de diseño, no defecto de configuración.
**Regla del maestro:** *"No automatizar inscripción a secuencias desde workflows. Sustituir por email automatizado de marketing o tarea para inscripción manual."*

| ID | Nombre | ID HubSpot | Estado al corte | Objeto |
|---|---|---|---|---|
| WF-003 | Actualizar estatus y enviar secuencia | 1808076077 | Encendido | Negocio |
| WF-004 | Enviar secuencia desde contacto | 1807994268 | — | Negocio |
| WF-007 | Enviar secuencia desde contacto + 2 días | 1809267363 | Apagado | Contacto |
| WF-020 | Enviar secuencia | 1808682771 | Encendido | Contacto |
| WF-034 | Realizar envío de secuencia | 1808851292 | Mantener OFF | Negocio |

Detalle WF-034: para niveles 1–3 y para cartera totalmente liquidada, usar email automatizado aprobado o tarea de inscripción manual según licencia; detener el seguimiento con la siguiente compra.

### 4.2 Familia 2 — Comunicaciones activas sin aprobación (4 casos)

**Naturaleza:** bloqueo por definición del cliente (copy, canal, remitente, destinatario, consentimiento), no defecto técnico.

| ID | Nombre | ID HubSpot | Estado al corte | Requisito |
|---|---|---|---|---|
| WF-010 | Correo interno a involucrados y actualizar campos | 1808160659 | **Encendido** (debía estar OFF) | Aprobar copy, canal, remitente y destinatario exacto |
| WF-011 | Correo interno a DG | 1807927091 | **Encendido** (debía estar OFF) | Aprobar copy, canal, remitente y destinatario exacto |
| WF-028 | Notificar a cliente | 1808892052 | **Encendido** (debía estar OFF) | Aprobar copy, remitente, consentimiento y titular |
| WF-040 | Notificaciones a cliente | 1808818002 | OFF | Solo al titular tras baja definitiva aprobada, con asociación, copy, remitente y consentimiento validados |

Nota WF-028: el maestro añade que **el control mensual de marketing debe sumar Solicitantes + Inversionistas, no superar 7,000 y desclasificar cada alta al mes siguiente.**
Nota WF-040: *"Una liquidación de campaña no debe dispararla."*

### 4.3 Familia 3 — Nombres desalineados entre maestro y HubSpot (4 casos documentados)

**Naturaleza:** cosmético / trazabilidad. Corrección de minutos.

| ID | Nombre en el maestro | Nombre real en HubSpot | ID HubSpot |
|---|---|---|---|
| WF-004 | `… Nº 04 \| Enviar secuencia desde contacto \| V1` | `… Nº 04 \| Enviar secuencia desde contacto + 15 días \| V1` | 1807994268 |
| WF-021 | `… Nº 04 \| Notificaciones internas al asesor \| V1` | `… Nº 04 \| Notificaciones a asesor asignado \| V1` | 1808816250 |
| WF-055 | `… Etapa 02 \| Nº 03 \| Recordatorios por vencimiento 15 \| V1` | `… Etapa 02 \| Nº 02 \| Recordatorios antes del 15 mes \| V1` | 1820860318 |
| WF-060 | `… Etapa 03 \| Nº 01 \| Mover a cierre por Ejecución de garantía \| V1` | `… Etapa 03 \| Nº 01 \| Mover a ejecución de garantía \| V1` | 1820907946 |

**El documento declara 5 diferencias de nombre pero solo documenta 4.** La quinta no está identificada en ninguna ficha.

### 4.4 Familia 4 — Cálculo dentro de HubSpot que debe provenir de la API (4 casos)

**Naturaleza:** limitación de arquitectura. Sin Data Hub, HubSpot no debe transformar ni calcular.

| ID | Regla de diseño |
|---|---|
| WF-053 | HubSpot no debe calcular recurrencias mensuales ni días hábiles. Monific envía `fecha_proximo_recordatorio`, monto y fecha; el workflow solo dispara el aviso aprobado. Hallazgo de auditoría: **bug de trigger anual.** |
| WF-054 | La API calcula el recordatorio previo al día 15. HubSpot espera la fecha recibida y crea tarea/notificación aprobada. |
| WF-055 | Activar con `dias_de_mora` enviado por Monific y valor ≥ 31. **HubSpot no calcula la mora.** |
| WF-027 | `nivel_registro` es el estado canónico en Contacto. Sin Data Hub no se transforman valores dentro de HubSpot. |
| UNE-02 | Sin Data Hub no generar serie de folio ni calcular 30 días hábiles. |

### 4.5 Familia 5 — Destinatarios y propietarios mal configurados (3 casos)

**Naturaleza:** defecto real de configuración, atribuible a implementación.

| ID | Nombre | ID HubSpot | Estado | Hallazgo |
|---|---|---|---|---|
| WF-050 | Asignar propietario de cobranza | 1820379477 | ON | **Asigna al equipo equivocado** (a Atención en lugar de Cobranza). Debe usar propietario/equipo, no una persona fija. Hallazgo CON-101 |
| WF-058 | Propiedades de entrada | 1820913996 | ON | Notificación "Decisión de Refinanciamiento" **sin destinatarios**. Hallazgo CON-193 (marcado tentativo) |
| WF-061 | Propiedades y Notificaciones | 1820908035 | ON | **Nombres personales hardcodeados (Vianey / Raquel).** Deben reemplazarse por roles/equipos. Hallazgos CON-111, CON-148, CON-150, CON-281 |

### 4.6 Familia 6 — Duplicados y solapes (3 casos)

| ID | Hallazgo | Estado real |
|---|---|---|
| WF-054 | **Réplica de WF-053** ("Recordatorios antes del 15 mes"). Hallazgos CON-280, CON-105, CON-189, CON-190 | Duplicado confirmado |
| WF-059 | Mueve a Cierre por refinanciamiento terminal. **Probable solape con WF-056.** Hallazgos CON-112, CON-211 | Marcado tentativo |
| WF-035 | Duplicado de actualización de propiedades. Regla: consolidar en la API y en un solo workflow | **La propia auditoría indica que el duplicado ya se eliminó** |

### 4.7 Familia 7 — Etapa destino equivocada (1 caso)

| ID | Debe hacer | Hace realmente |
|---|---|---|
| WF-056 | Mover a **Campaña Liquidada** con saldo insoluto 0, mensualidades restantes 0 y conciliación validada | **Mueve a Cierre por refinanciamiento** (Etapa 03 Nº 2). Hallazgo CON-109 |

Este es el defecto funcional más limpio del inventario: el destino es objetivamente distinto al especificado.

### 4.8 Familia 8 — Disparo por tiempo en lugar de por evento o autorización (4 casos)

| ID | Regla correcta | Comportamiento auditado |
|---|---|---|
| WF-057 | Mover a Ejecución de Garantía con mora confirmada por API **y autorización documentada**; no solo por tiempo en etapa | Transiciona automáticamente con `mora >= 61`. Hallazgos CON-107, CON-110, CON-111, CON-145 |
| WF-039 | Cerrar el onboarding **solo por baja definitiva confirmada** | Inscribe Negocios que llevan 90 días en Cierre |
| WF-032 | Congelar solo si no existen inversiones activas, saldo = 0 y 90 días sin actividad. **Nunca congelar solo por falta de login cuando existan inversiones activas** | Pendiente de corrección |
| WF-037 | Debía permanecer OFF; corregir `motivo_congelado` como dropdown | **Se observó encendido** |

### 4.9 Familia 9 — Campos de otro proceso (1 caso, el más grave)

| ID | Hallazgo |
|---|---|
| WF-039 | Utiliza `contrato_firmado`, `folio_inscripcion` y `link_del_expediente` — **campos propios de Solicitantes** — dentro del ciclo de Inversionistas. Deben eliminarse. |

---

## 5. Reglas corregidas que sustituyen definiciones anteriores

Estas fichas traen la definición sustituta en negrita dentro del maestro. Son las que exigen "qué versión se sustituye" en la respuesta.

| ID | ID HubSpot | Regla vigente que sustituye a la anterior |
|---|---|---|
| WF-025 | 1808818247 | Debe permanecer OFF. El onboarding cambia a Activo **solo con la primera compra confirmada por Monific**; saldo ≥ $1,000 genera seguimiento, pero no nivel 4 ni cambio de etapa |
| WF-026 | 1808819073 | Congelar únicamente después de 15 días sin depósito desde la activación STP, con datos reales sincronizados. Mantener OFF hasta demostrar el caso y su reingreso |
| WF-027 | 1808747892 | `nivel_registro` es el estado canónico en Contacto y solo se espejea al onboarding si es necesario. Corregir el bug que deja cuentas activas con más de un Deal sin nivel 4; `state`/`estatus_conversion` solo puede ser espejo o retirarse |
| WF-028 | 1808892052 | Apagar y mantener OFF hasta aprobar copy, remitente, consentimiento y titular. Control mensual de marketing = Solicitantes + Inversionistas, tope 7,000, desclasificar cada alta al mes siguiente |
| WF-031 | 1808852539 | Mantener OFF. El onboarding pasa a Cierre **solo por baja definitiva de la cuenta confirmada por Monific**; una liquidación, el fin de un Proyecto o el paso del tiempo no sustituyen esa condición |
| WF-032 | 1808890239 | Congelar solo si no existen inversiones activas, saldo = 0 y 90 días sin actividad |
| WF-033 | 1808890885 | Cada PURCHASE, SOLD o LIQUIDATION se conserva como movimiento separado y se deduplica por `move_id`, asociado a Contacto y Proyecto. Requiere prueba de volumen, retry e idempotencia |
| WF-034 | 1808851292 | Mantener OFF. Niveles 1–3 y cartera liquidada: email automatizado aprobado o tarea manual; detener seguimiento con la siguiente compra |
| WF-036 | 1808815771 | Reactivar solo con nueva compra confirmada. **Reinversión no es un evento separado**: es PURCHASE normal interpretado según el estado previo, sin duplicar el onboarding |
| WF-037 | 1808817955 | Apagar, corregir `motivo_congelado` como dropdown y usar solo las reglas aprobadas antes de activarlo |
| WF-039 | 1808890376 | Eliminar los campos copiados de Solicitantes y cerrar el onboarding solo por baja definitiva confirmada |
| WF-040 | 1808818002 | Solo al titular tras baja definitiva aprobada, con asociación, copy, remitente y consentimiento validados. Una liquidación de campaña no debe dispararla |

---

## 6. Las ausencias: lo que no existe

Este bloque pesa más que los bugs, porque no se corrige — se construye.

### 6.1 UNE: los 6 flujos no existen

Las seis fichas UNE-01 a UNE-06 declaran: *"No se acreditó una correspondencia canónica en el inventario de HubSpot"* y *"No existe workflow documentado en el master fuente."*

| ID | Función | Regla de diseño |
|---|---|---|
| UNE-01 | Crear/registrar Ticket UNE | Crear Ticket en pipeline UNE desde formulario/correo aprobado, asociar contacto y asignar a D.C. |
| UNE-02 | Definir folio y fechas regulatorias | Usar ID nativo como folio o recibir folio, trimestre y fecha límite calculados por la API |
| UNE-03 | Acuse de recepción | Enviar correo aprobado con folio y plazo, desde el buzón autorizado. **Falta definir copy, remitente, consentimiento y destinatario** |
| UNE-04 | Tarea de dictamen | Tarea al propietario con vencimiento a 10 días; recordatorios en días 5 y 8. No usar tarea recurrente ni destinatario fijo |
| UNE-05 | Escalamiento por vencimiento | Notificar a superior/equipo y crear tarea urgente. **La fecha debe llegar calculada desde Monific** |
| UNE-06 | Cierre con dictamen | Permitir cierre solo con dictamen, resultado y fecha. Nueva reclamación = Ticket nuevo |

### 6.2 Otras ausencias verificadas

| Ausencia | Evidencia |
|---|---|
| **Formulario definitivo de Solicitantes** | Los tres candidatos (`1640673709`, `1832556831`, `1834467729`) "no demuestran este recorrido completo" |
| **WF-055 no tiene objeto propio en HubSpot** | Su ficha lo mapea al ID `1820860318`, que es el mismo de WF-054 |
| **Ticket por campaña asociado a Proyecto** | Deduplicado por ID externo — sin demostrar |
| **Cadena completa del despacho ARI** | Días 15/16/30/61 — sin demostrar en workflows |
| **Diccionario de propiedades (T1)** | Prácticamente todas las fichas de Solicitantes e Inversionistas dicen `[nombre interno pendiente de contrato técnico]` |
| **32 workflows del portal sin mapear** | 96 en el portal − 64 canónicos |

### 6.3 Estado real de la API en producción

| Métrica | Valor |
|---|---|
| Llamadas registradas | 16,279 |
| Errores 4xx | 766 |
| Rechazos por valores de proyecto no admitidos | 741 |

**Diagnóstico:** los 741 rechazos concentrados en un solo tipo de causa apuntan a un problema de **catálogo de valores**, no a un problema de integración. Es corregible con la definición del catálogo autorizado.

### 6.4 Contradicción de modelo de datos

El documento técnico v1 del 9 de marzo modela las campañas como **Deal**. El modelo vigente usa **Proyecto** como objeto madre, e INV-06 elimina el Deal padre. La propia hoja `FUENTES` del Control Único lo reconoce: *"contradice el uso posterior de Proyecto; P4 debe resolverlo."*

Es la contradicción arquitectónica de fondo y debe resolverse antes de programar cualquier workflow de Inversionistas.

---

## 7. Defectos internos detectados en los documentos del cliente

Este bloque no es defensivo: es material necesario para que la sesión sea resolutiva. Un pendiente marcado en rojo sin defecto acreditado no puede cerrarse con evidencia, porque no hay nada que demostrar.

### 7.1 Rojos que no acreditan un defecto (6 casos)

| ID | Motivo del rojo | Situación real |
|---|---|---|
| WF-051 | *"No localizado en la relación de flujos de la auditoría; requiere validación puntual"* | No es un defecto probado |
| WF-052 | *"No localizado en la relación de flujos de la auditoría; requiere validación puntual"* | No es un defecto probado |
| WF-060 | *"No localizado en la relación de flujos de la auditoría; requiere validación puntual"* | No es un defecto probado |
| WF-035 | Marcado en rojo | Su propio rastro dice: *"La auditoría indica que se eliminó el duplicado"* — **ya resuelto** |
| WF-039 | Marcado en rojo | Su propio rastro dice: *"Configuración aceptada, activación aún pendiente"* — contradice el texto de la misma ficha |
| WF-058 / WF-059 / WF-061 | Hallazgos marcados literalmente **"(tentativo)"** | Requieren confirmación antes de exigir corrección |

**3 de los 13 rojos de Cobranza** están marcados por no haber sido encontrados en la auditoría, no por tener un defecto.

### 7.2 Contradicción de ID entre WF-054 y WF-055

| Ficha | ID HubSpot declarado | Estado auditado declarado |
|---|---|---|
| WF-054 | 1820860318 (coincidencia exacta) | **OFF** |
| WF-055 | 1820860318 (posible correspondencia) | **ON** |

**Un mismo workflow no puede estar simultáneamente encendido y apagado.** La lectura correcta es que WF-055 no tiene un workflow propio en HubSpot y su ficha se está mapeando al objeto de WF-054. Requiere resolución en la sesión.

### 7.3 Contradicción tablero vs. ficha

WF-028 y WF-037 aparecen en **rojo en el tablero** y en **amarillo en su ficha individual**. El conteo de rojos de Inversionistas da **3 en el resumen** y **5 en el tablero**.

### 7.4 Dos cadencias de cobranza incompatibles en el mismo archivo

| Ubicación | Cadencia |
|---|---|
| Sección 1 del maestro 03 | Días **15 / 16 / 30 / 61** |
| Sección 6 y fichas de Cobranza | Semana 1 Monific / semana 2 despacho / acción legal desde semana 3 |

La matriz de comunicación resuelve esto a favor de **días 15/16/30/61** (ver sección 8.4).

### 7.5 Reglas de diseño sin contenido

WF-045 y WF-059 tienen como regla de diseño la frase **"Implementado con validación"**. Es texto de plantilla, no una regla verificable. No se puede construir un caso de prueba contra ella.

### 7.6 Límite de instrumentación reconocido

El propio documento admite que **el historial de ejecución de 5 workflows no estuvo disponible** por una consulta a la API fallida. Parte del "no verificado" es límite de la instrumentación de la auditoría, no ausencia de configuración.

---

## 8. Análisis de la matriz completa de comunicación

**Archivo:** `03. Matriz completa de comunicación (1).md` — 107,373 bytes, 602 líneas.
**Contenido declarado:** Parte I arquitectura y matriz · Parte II biblioteca de plantillas y textos · Parte III cadencias, reglas y métricas.

### 8.1 Universo de comunicaciones

| Área | Cantidad |
|---|---|
| Cobranza (COB-001 a COB-033) | 33 |
| Solicitantes (SOL-001 a SOL-022) | 22 |
| Inversionistas (INV-001 a INV-015) | 15 |
| ATC (ATC-001 a ATC-007) | 7 |
| PDF institucional (PDF-001 a PDF-004) | 4 |
| **Total** | **81** |

### 8.2 Distribución por canal

| Canal | Cantidad |
|---|---|
| Email | 42 |
| Notificación interna | 15 |
| WhatsApp | 10 |
| PDF | 4 |
| Tarea interna | 2 |
| Tarea | 1 |
| Combinados (PDF+Email, Email+PDF, Email+WhatsApp, Notif+Email interno, Notif+copia, Notif+tarea, Notif+asignación) | 7 |

**Piezas que incluyen email: 45. Piezas que incluyen WhatsApp: 11** — este último dato cuadra con las "11 plantillas de WhatsApp aprobadas" que exige el Control Único.

### 8.3 Estado de implementación declarado

| Estado | Cantidad |
|---|---|
| **Crear** (no existe todavía en HubSpot) | **77** |
| **Corregir** (existe con defecto) | 4 — ATC-001, ATC-007, COB-010, COB-011 |
| Mantener/validar | 0 en la matriz principal, aunque la leyenda declara tres estados |

**Lectura crítica: el documento reconoce que 77 de 81 comunicaciones no existen todavía en el portal.** Es la especificación para construirlas, no la evidencia de haberlas construido.

### 8.4 Lo que la matriz sí resuelve

| Requisito del maestro / Control Único | Estado |
|---|---|
| Copy aprobado por comunicación (asunto, preheader, cuerpo, CTA, variante B) | **Cubierto** en secciones 7 a 10 |
| Destinatario explícito | **Cubierto** — los 81 |
| Trigger explícito | **Cubierto** — los 81 |
| Plantilla base con bloque regulatorio CNBV fijo no editable | **Cubierto** — coded template con leyenda de institución autorizada por la CNBV y leyenda de no garantía del Gobierno Federal |
| Versión de texto plano obligatoria | **Cubierto** |
| Reglas de supresión y frecuencia | **Cubierto** — 10 reglas, horario 8:00–19:00 CDMX, máx. 1 pieza por objetivo cada 24 h |
| **Cadena del despacho ARI** | **Cubierto — cierra una omisión del maestro 03** |
| Gate de Legal/Compliance | **Cubierto** vía propiedad `compliance_aprobado` = Sí como bloqueo de envío |

Detalle de la cadena ARI incorporada:

| ID | Momento | Contenido |
|---|---|---|
| COB-030 | Día 15 previo a mora temprana | Preparación de tabla de adeudos |
| COB-031 | Día 16+ / mora temprana | Inicio de cobranza amistosa con apoyo del despacho externo |
| COB-032 | Día 30 a 60 / mora moderada o grave | Cobranza formal |
| COB-033 | Día 61+ | Prejudicial/judicial y ejecución de garantía |

Usa la cadencia de **días 15/16/30/61**, no la de semanas. Esto resuelve la contradicción del punto 7.4.

Remitentes definidos:

| Dominio | Alias |
|---|---|
| Solicitantes (comercial, documentación, evaluación, formalización, cobranza preventiva, mora, incumplimiento, garantía, jurídicos, avisos a inversionistas) | `solicitantes@monific.com` |
| Inversionistas (onboarding, fondeo, inversiones, rendimientos, reactivación, atención al cliente) | `contacto@monific.com` |

Fallback declarado: si no se puede usar el alias, asignar por equipo a la persona responsable según el flujograma (A.A.S. o A.A.I.).

### 8.5 Lo que la matriz NO resuelve

| Hueco | Evidencia de verificación |
|---|---|
| **No hay un solo `WF-xxx` en todo el documento** | 0 ocurrencias de la cadena `WF-` en 602 líneas. El Control Único exige "workflow vinculado" por comunicación |
| **Ningún URL ni ID de asset de HubSpot** | 0 ocurrencias de "publicado". Los 81 IDs son códigos internos de la matriz, no IDs de HubSpot |
| **"Consentimiento" no aparece nunca** | 0 ocurrencias. Existe `whatsapp_opt_in` (1 sola mención, en INV-001) y `compliance_aprobado` (1 sola mención, en la regla 5 de la sección 11) |
| **Ninguno de esos dos campos está en los bundles de propiedades** | No están en `PB-SOL-*`, `PB-INV-*`, `PB-ATC`, `PB-COB-*` → no entran a T1 → no son programables |
| **No hay tipos de suscripción ni manejo de baja** | 0 ocurrencias de "desuscripción" / "unsubscribe". Obligatorio para marketing email en HubSpot |
| **UNE no existe en la matriz** | Solo 2 menciones incidentales (línea 63: "escala a TI o a UNE según tipología"; línea 96: "Proceso UNE activo" dentro del bundle PB-ATC). **Ninguna comunicación UNE definida** |
| **Sin remitente para ATC ni para Cobranza** | Cobranza, garantía y jurídico quedan agrupados bajo `solicitantes@monific.com`, lo que contradice la regla 2 del propio documento: "remitentes separados por dominio operativo" |
| **Desbalance de Cobranza** | 33 comunicaciones contra 15 workflows existentes, sin mapeo ni indicación de cuáles faltan |
| **El cupo de 7,000 contactos de marketing no aparece** | 0 menciones, con 45 piezas que llevan email |

### 8.6 Defecto interno A: los triggers de Inversionistas están corridos

La sección 4 (matriz resumen) y la tabla "Workflows de Inversionistas" (detalle) se contradicen entre INV-008 e INV-014. La tabla de detalle es la coherente, porque el trigger corresponde al nombre de la pieza.

| ID | Nombre de la pieza | Trigger en sección 4 | Trigger en tabla de detalle |
|---|---|---|---|
| INV-008 | Saldo disponible por rendimiento o pago aplicado | Inversión confirmada | Pago o rendimiento aplicado por plataforma |
| INV-009 | Reactivación 30 días | Pago/rendimiento aplicado | **30 días sin invertir** |
| INV-010 | Reactivación 90 días | **Solicitud de retiro recibida** | **90 días sin invertir** |
| INV-011 | Reactivación 180 días / preferencias | 30 días sin invertir | **180 días sin invertir** |
| INV-012 | Reactivación 360 días / recuperación | 90 días sin invertir | **360 días sin invertir** |
| INV-013 | Reinversión post-campaña concluida | 180 días sin invertir | Campaña liquidada y capital liberado |
| INV-014 | Retención por cierre de cuenta | 360 días sin invertir | Solicitud de cierre de cuenta |
| INV-015 | Acompañamiento posterior a recuperación | Proyecto liquidado | Distribución por garantía o recuperación aplicada |

**El error se propaga:** la sección 11 ("Flujos críticos") repite la versión equivocada — *"INV-009 / rendimiento aplicado"* y *"INV-010 / retiro"*. Está mal en 2 de 3 lugares del documento.

### 8.7 Defecto interno B: canal y estado inconsistentes en Inversionistas

| ID | Canal en sección 4 | Canal en tabla de detalle |
|---|---|---|
| INV-006 | Email | WhatsApp + tarea si saldo alto |
| INV-007 | Email + PDF | Tarea asesor + WhatsApp manual opcional |
| INV-008 | Notificación interna | WhatsApp / tarea si saldo supera mínimo |
| INV-009 | Email | WhatsApp + email si no hay WhatsApp |
| INV-010 | Email | WhatsApp manual + tarea llamada si alto valor |
| INV-013 | Email | WhatsApp + tarea asesor |

Además INV-005 aparece como **"Crear"** en la sección 4 y como **"Mantener interno"** en la tabla de detalle.

### 8.8 Defecto interno C: tokens que no existen en HubSpot

De 66 tokens distintos usados en el copy, estos apuntan a namespaces inexistentes y requieren propiedades de HubSpot alimentadas por Admin:

| Token | Usos |
|---|---|
| `{{app.available_balance}}` | 3 |
| `{{app.deep_link_opportunities}}` | — |
| `{{app.deep_link_add_funds}}` | — |
| `{{app.deep_link_login}}` | — |
| `{{payment.fecha_limite}}` | 3 |
| `{{payment.monto}}` | 3 |
| `{{payment.periodo}}` | 2 |
| `{{payment.fecha_limite_reporte}}` | 2 |
| `{{payment.capital}}` | 1 |
| `{{payment.rendimiento}}` | 1 |
| `{{payment.fecha}}` | 1 |
| `{{payment.detalle}}` | 1 |
| `{{investment.amount}}` | 2 |
| `{{withdrawal.amount}}` | 1 |
| `{{email.preheader}}` | 1 — no es el token nativo de preview text |

Tablas dinámicas que HubSpot no genera nativamente sin contenido programable:

- `{{tabla_adeudos}}`
- `{{tabla_calendario_pagos}}`
- `{{tabla_aplicacion_pagos}}`

**Nota de precisión:** los 11 tokens `{{module.*}}` **sí son válidos** — son campos de módulo HubL dentro de una coded template, y su uso es correcto.

**Convención mixta de nombres internos:** `deal.link_drive` y `deal.observaciones_documentales` en español convivan con `deal.days_past_due`, `deal.next_due_amount` y `deal.guarantee_type` en inglés. Ninguno está confirmado como internal name real.

---

## 9. Conflictos entre la matriz de comunicación y las decisiones canónicas del 31 de julio

Estos cuatro puntos indican que la matriz **es anterior a la actualización de Inversionistas del 31 de julio o no la incorporó**. Deben resolverse antes de usarla como respuesta formal.

| # | Conflicto | Decisión canónica | Qué dice la matriz | Acción |
|---|---|---|---|---|
| 1 | **Retiros** | INV-11: *"Retiros y UNE quedan fuera"* del ciclo de Inversionistas | `withdrawal.amount` está en el bundle TK-INV, y la sección 4 usa "Solicitud de retiro recibida" como trigger de INV-010. La sección 11 lo repite: *"INV-010 / retiro"* | Eliminar el token y el trigger |
| 2 | **Cupo de contactos de marketing** | WF-028 / INV-01: el control mensual suma Solicitantes + Inversionistas, no supera 7,000 y desclasifica cada alta al mes siguiente | 0 menciones, con 45 piezas que llevan email | Diseñar el control |
| 3 | **Vocabulario de `nivel_registro`** | Niveles 1–4, con el 4 solo por primera compra confirmada | INV-001 usa `nivel_registro = registro_simple` | Homologar catálogo |
| 4 | **Cadencia de reactivación** | WF-027: sin Data Hub no se transforman ni calculan valores dentro de HubSpot; se toman directo de lo que envíe la API | INV-009 a INV-012 dependen de `days_since_last_investment`, un campo calculado | O Admin envía el dato, o la cadencia no es construible como está diseñada. Entra a T2 |

Compromisos nuevos que aparecen solo en la matriz y no en el maestro (requieren confirmación):

- **SLA de primera atención de ATC = 5 minutos** (ATC-003). El maestro no lo establece.
- Cadencia preventiva de cobranza **T-10, T-7, T-5, T-2, D0**, más fina que la que implementan los workflows existentes (WF-054/055 operan alrededor del día 15 y WF-057 en mora ≥ 61).

---

## 10. Clasificación de los 70 pendientes por naturaleza

Clasificación elaborada por B&O sobre las 70 fichas del maestro 03, **sujeta a validación conjunta en la sesión**.

| # | Naturaleza del pendiente | Fichas | % |
|---|---|---|---|
| 1 | Bloqueado por definición o aprobación de Monific (copy, remitente, consentimiento, catálogo de proyecto, cadencia ARI, canal UNE) | 15 | 21% |
| 2 | Configuración correcta; solo falta evidencia o prueba documentada | 14 | 20% |
| 3 | Construcción nueva no contemplada en el alcance original (6 UNE, formulario, Ticket por campaña, modelo de movimientos) | 12 | 17% |
| 4 | **Corrección de configuración atribuible a B&O** | **10** | **14%** |
| 5 | Limitación de plataforma (secuencias por licencia, ausencia de Data Hub) | 9 | 13% |
| 6 | Marcado en rojo sin defecto probado | 6 | 9% |
| 7 | Homologación de nombres (cosmético) | 4 | 6% |
| | **Total** | **70** | **100%** |

**Dato central: de los 29 rojos, alrededor de 10 son defectos de configuración atribuibles a B&O.** El resto es plataforma, definición pendiente de Monific, alcance nuevo o hallazgo no acreditado.

Los 10 defectos de configuración a corregir:

1. WF-050 — asignación al equipo equivocado
2. WF-056 — etapa destino equivocada
3. WF-058 — notificación sin destinatarios
4. WF-061 — nombres personales hardcodeados
5. WF-039 — campos de Solicitantes dentro de Inversionistas
6. WF-054 — duplicado de WF-053
7. WF-057 — disparo por tiempo sin autorización documentada
8. WF-037 — encendido debiendo estar OFF
9. WF-028 — encendido debiendo estar OFF
10. WF-010 / WF-011 — comunicaciones internas encendidas sin aprobación

### 10.1 El proceso limpio: Servicio / ATC

**Servicio es el único bloque sin rojos:** 9 fichas en amarillo, 0 en rojo, y todas las observaciones son preventivas:

| ID | Observación |
|---|---|
| WF-041 | Asignar al equipo de Atención por rotación nativa; si el horario no puede gobernar la rotación, asignar al equipo y reasignar manualmente |
| WF-042 | Usar SLA/espera nativa y notificar al superior del propietario o a un equipo; no a una persona fija |
| WF-043 | Mover a En Atención solo cuando exista primera respuesta/actividad del agente |
| WF-044 | Usar fecha nativa de primera respuesta cuando esté disponible |
| WF-046 | Conservar al E.A.C. como responsable de seguimiento; registrar responsable TI como dato manual |
| WF-047 | Al entrar a Escalado TI registrar fecha/hora y solicitar categoría, subcategoría y descripción |
| WF-048 | Esperar 48 horas y notificar al superior/equipo. No usar destinatarios personales fijos |
| WF-049 | Al cerrar registrar fecha y exigir resolución. Métricas con campos nativos |

**Es el bloque que se puede cerrar con evidencia primero** y sirve para demostrar el método de cierre antes de discutir Cobranza.

---

## 11. Ruta de cierre propuesta

### 11.1 Antes de la sesión del lunes

| # | Acción | Bloque | Esfuerzo |
|---|---|---|---|
| 1 | Corregir el corrimiento de triggers INV-008 a INV-014 en la sección 4 y en Flujos críticos de la matriz de comunicación; eliminar el trigger de retiro | Matriz | Bajo |
| 2 | Homologar los 4 nombres de workflow desalineados (WF-004, WF-021, WF-055, WF-060) e identificar el quinto que el documento declara pero no documenta | Maestro 03 | Bajo |
| 3 | Apagar WF-010, WF-011, WF-028 y WF-037 con evidencia antes/después | Configuración | Bajo |
| 4 | Reemplazar los nombres hardcodeados de WF-061 por roles/equipos | Configuración | Bajo |
| 5 | Agregar destinatarios a WF-058 | Configuración | Bajo |
| 6 | Corregir la etapa destino de WF-056 a Campaña Liquidada | Configuración | Medio |
| 7 | Eliminar de WF-039 los campos `contrato_firmado`, `folio_inscripcion` y `link_del_expediente` | Configuración | Medio |
| 8 | Corregir la asignación de equipo de WF-050 | Configuración | Bajo |
| 9 | Cerrar el bloque completo de Servicio con evidencia de las 9 fichas | Servicio | Medio |
| 10 | Agregar la columna `WF-xxx` a las cuatro tablas de workflows de la matriz de comunicación | Matriz | Medio |
| 11 | Separar los ~14 tokens dependientes de Admin en una lista formal de entrada a T2 | Matriz | Bajo |

### 11.2 Puntos a resolver en la sesión (requieren decisión de Monific)

| # | Punto | Por qué no se puede resolver antes |
|---|---|---|
| 1 | **Deal vs. Proyecto** como objeto madre de campaña | Decisión de arquitectura; bloquea todo Inversionistas |
| 2 | **Diccionario de propiedades (T1)** — internal names confirmados | Sin esto no hay nada programable ni tokens resolubles |
| 3 | **Catálogo de valores de proyecto** admitidos por la API | Explica los 741 rechazos |
| 4 | Contradicción de ID entre **WF-054 y WF-055** | El documento reporta el mismo ID en dos estados |
| 5 | Los **3 rojos no localizados** en la auditoría (WF-051, WF-052, WF-060) | Sin defecto acreditado no hay criterio de cierre |
| 6 | Confirmar que **WF-035 ya está resuelto** según la propia auditoría | Contradicción interna del documento |
| 7 | Alcance de los **6 flujos UNE** y sus comunicaciones | Construcción nueva, no corrección |
| 8 | Diseño del **control de 7,000 contactos de marketing** | Definición de negocio |
| 9 | Origen del dato de **reactivación 30/90/180/360** | Requiere que Admin lo envíe |
| 10 | Confirmar el **SLA de 5 minutos de ATC** | Aparece solo en la matriz |
| 11 | Alias de remitente para **Cobranza y ATC** | Definición de dominio operativo |
| 12 | Los **32 workflows del portal sin mapear** | Requiere decisión: adoptar, archivar o eliminar |

### 11.3 Respuesta propuesta a las cuatro confirmaciones

| # | Solicitud del cliente | Respuesta propuesta |
|---|---|---|
| 1 | Recepción y acceso a la estructura | **Confirmado.** Estructura recibida y revisada de punta a punta: 00_LEER_PRIMERO, maestro operativo 03, Control Único 05 y matriz de comunicación |
| 2 | Trabajar sobre estas versiones sin crear una matriz adicional | **Confirmado.** No se generará ninguna matriz nueva. Las respuestas se harán sobre los mismos másteres y el Control Único, en la carpeta 02_RESPUESTA_BNO, con el formato de siete campos de evidencia solicitado |
| 3 | Sesión del lunes a las 15:00 h | **Confirmada**, con agenda acotada a los 12 puntos de decisión de 11.2. Se propone no usar la sesión para revisar los puntos ya corregidos, que se entregarán documentados antes |
| 4 | Qué correcciones quedarán incorporadas antes de la reunión | Las 11 acciones de 11.1, con evidencia antes/después, caso de prueba, resultado esperado y real, URL o ID de configuración y fecha de ejecución |

**Punto adicional a plantear:** de las 70 fichas, 15 están bloqueadas por definición o aprobación de Monific y 12 corresponden a construcción nueva no contemplada en el alcance original. Conviene que la sesión los separe explícitamente de los 10 defectos de configuración, para que el criterio de cierre de cada grupo sea distinto y verificable.

---

## 12. Anexo: método de verificación aplicado

| Verificación | Método |
|---|---|
| Duplicidad del archivo 03 | SHA-256 comparado entre ambos archivos |
| Conteo de fichas, estados y rojos | Extracción estructurada de las 70 fichas del maestro 03 por campo (Estatus, Dentro de HubSpot, Rastro de auditoría) |
| Nombres desalineados | Búsqueda del patrón "Posible correspondencia, no exacta" en las 70 fichas |
| Conteo de comunicaciones, canales y estados | Parseo de las 81 filas de la sección 4 de la matriz |
| Inventario de tokens | Extracción de todas las ocurrencias `{{...}}` del documento y clasificación por namespace |
| Ausencias (UNE, consentimiento, WF-, asset IDs) | Búsqueda exhaustiva de cadenas en las 602 líneas de la matriz |

**Límites de esta revisión:** el análisis se hizo sobre los archivos entregados. No incluye verificación en vivo del portal de HubSpot. Los estados "encendido / apagado al corte" son los declarados por el maestro 03 y deben reconfirmarse en el portal al momento de ejecutar cada corrección, junto con la captura de evidencia antes/después.

---

## 13. Registro de versiones

| Versión | Fecha | Cambio |
|---|---|---|
| 1.0 | 2026-08-03 | Documento inicial. Consolida la solicitud de Monific, el análisis de las 70 fichas del maestro operativo 03, el análisis de las 81 comunicaciones de la matriz, los defectos internos de ambos documentos, los 4 conflictos con las decisiones canónicas del 31 de julio, la clasificación de pendientes y la ruta de cierre |

---

*Black & Orange · Preparado por Emmanuel Chulin · 3 de agosto de 2026*
